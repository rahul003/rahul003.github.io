Day Tracker :
Many times we wonder where we lost time. Time just flies by, and with this app we want to track it.
Track how much time you spend on studies, gaming, sports, etc. This app shows you the percentages
of time spent, so that you can analyse later. And you can correct it if need be.

Before starting any activity you just need to press the timer for that and when you start something else, change the timer. This has separate timers for each activity.

This is an Eclipse project

Pending features:
1. Ability to run as service
2. Ability to customize the categories