/** Automatically generated file. DO NOT MODIFY */
package com.example.better;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}