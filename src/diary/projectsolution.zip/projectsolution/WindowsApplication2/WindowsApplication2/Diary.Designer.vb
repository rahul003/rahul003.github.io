﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.MainToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SettingsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutSoftwareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MainToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChnagePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadMeToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainToolStripMenuItem
        '
        Me.MainToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem, Me.ExitToolStripMenuItem1})
        Me.MainToolStripMenuItem.Name = "MainToolStripMenuItem"
        Me.MainToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.MainToolStripMenuItem.Text = "Main"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.ExitToolStripMenuItem.Text = "Lock"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(99, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toolStripSeparator5, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(113, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.AboutToolStripMenuItem.Text = "&About..."
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.ListView1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(243, 112)
        Me.ListView1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(635, 407)
        Me.ListView1.Sorting = System.Windows.Forms.SortOrder.Descending
        Me.ListView1.TabIndex = 1
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Date of Entry"
        Me.ColumnHeader1.Width = 255
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Title"
        Me.ColumnHeader2.Width = 369
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(39, 112)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(147, 55)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Create Entry"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(39, 452)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(147, 67)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Delete Entry"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'SettingsToolStripMenuItem1
        '
        Me.SettingsToolStripMenuItem1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SettingsToolStripMenuItem1.Name = "SettingsToolStripMenuItem1"
        Me.SettingsToolStripMenuItem1.Size = New System.Drawing.Size(54, 23)
        Me.SettingsToolStripMenuItem1.Text = "Main"
        '
        'ExitToolStripMenuItem2
        '
        Me.ExitToolStripMenuItem2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitToolStripMenuItem2.Name = "ExitToolStripMenuItem2"
        Me.ExitToolStripMenuItem2.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.ExitToolStripMenuItem2.Size = New System.Drawing.Size(152, 24)
        Me.ExitToolStripMenuItem2.Text = "Exit"
        '
        'SettingsToolStripMenuItem2
        '
        Me.SettingsToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem1})
        Me.SettingsToolStripMenuItem2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SettingsToolStripMenuItem2.Name = "SettingsToolStripMenuItem2"
        Me.SettingsToolStripMenuItem2.Size = New System.Drawing.Size(73, 23)
        Me.SettingsToolStripMenuItem2.Text = "Settings"
        '
        'ChangePasswordToolStripMenuItem1
        '
        Me.ChangePasswordToolStripMenuItem1.Name = "ChangePasswordToolStripMenuItem1"
        Me.ChangePasswordToolStripMenuItem1.Size = New System.Drawing.Size(193, 24)
        Me.ChangePasswordToolStripMenuItem1.Text = "Change Password"
        '
        'AboutToolStripMenuItem1
        '
        Me.AboutToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutSoftwareToolStripMenuItem, Me.ReadMeToolStripMenuItem})
        Me.AboutToolStripMenuItem1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AboutToolStripMenuItem1.Name = "AboutToolStripMenuItem1"
        Me.AboutToolStripMenuItem1.Size = New System.Drawing.Size(51, 23)
        Me.AboutToolStripMenuItem1.Text = "Help"
        '
        'AboutSoftwareToolStripMenuItem
        '
        Me.AboutSoftwareToolStripMenuItem.Name = "AboutSoftwareToolStripMenuItem"
        Me.AboutSoftwareToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.AboutSoftwareToolStripMenuItem.Size = New System.Drawing.Size(201, 24)
        Me.AboutSoftwareToolStripMenuItem.Text = "About Software"
        '
        'ReadMeToolStripMenuItem
        '
        Me.ReadMeToolStripMenuItem.Name = "ReadMeToolStripMenuItem"
        Me.ReadMeToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2
        Me.ReadMeToolStripMenuItem.Size = New System.Drawing.Size(201, 24)
        Me.ReadMeToolStripMenuItem.Text = "ReadMe"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(292, 64)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(525, 19)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Hi! Anything you want to tell me? Click on Create Entry and share your thoughts"
        '
        'MainToolStripMenuItem1
        '
        Me.MainToolStripMenuItem1.Name = "MainToolStripMenuItem1"
        Me.MainToolStripMenuItem1.Size = New System.Drawing.Size(54, 23)
        Me.MainToolStripMenuItem1.Text = "Main"
        '
        'ExitToolStripMenuItem3
        '
        Me.ExitToolStripMenuItem3.Name = "ExitToolStripMenuItem3"
        Me.ExitToolStripMenuItem3.Size = New System.Drawing.Size(152, 24)
        Me.ExitToolStripMenuItem3.Text = "Exit"
        '
        'SettingsToolStripMenuItem3
        '
        Me.SettingsToolStripMenuItem3.Name = "SettingsToolStripMenuItem3"
        Me.SettingsToolStripMenuItem3.Size = New System.Drawing.Size(73, 23)
        Me.SettingsToolStripMenuItem3.Text = "Settings"
        '
        'ChnagePasswordToolStripMenuItem
        '
        Me.ChnagePasswordToolStripMenuItem.Name = "ChnagePasswordToolStripMenuItem"
        Me.ChnagePasswordToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.ChnagePasswordToolStripMenuItem.Text = "Chnage Password"
        '
        'HelpToolStripMenuItem1
        '
        Me.HelpToolStripMenuItem1.Name = "HelpToolStripMenuItem1"
        Me.HelpToolStripMenuItem1.Size = New System.Drawing.Size(51, 23)
        Me.HelpToolStripMenuItem1.Text = "Help"
        '
        'AboutToolStripMenuItem2
        '
        Me.AboutToolStripMenuItem2.Name = "AboutToolStripMenuItem2"
        Me.AboutToolStripMenuItem2.Size = New System.Drawing.Size(152, 24)
        Me.AboutToolStripMenuItem2.Text = "About"
        '
        'ReadMeToolStripMenuItem1
        '
        Me.ReadMeToolStripMenuItem1.Name = "ReadMeToolStripMenuItem1"
        Me.ReadMeToolStripMenuItem1.Size = New System.Drawing.Size(152, 24)
        Me.ReadMeToolStripMenuItem1.Text = "Read Me"
        '
        'MenuToolStripMenuItem
        '
        Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.MenuToolStripMenuItem.Text = "Menu"
        '
        'ExitToolStripMenuItem4
        '
        Me.ExitToolStripMenuItem4.Name = "ExitToolStripMenuItem4"
        Me.ExitToolStripMenuItem4.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem4.Text = "Exit"
        '
        'SettingsToolStripMenuItem4
        '
        Me.SettingsToolStripMenuItem4.Name = "SettingsToolStripMenuItem4"
        Me.SettingsToolStripMenuItem4.Size = New System.Drawing.Size(61, 20)
        Me.SettingsToolStripMenuItem4.Text = "Settings"
        '
        'ChangePasswordToolStripMenuItem2
        '
        Me.ChangePasswordToolStripMenuItem2.Name = "ChangePasswordToolStripMenuItem2"
        Me.ChangePasswordToolStripMenuItem2.Size = New System.Drawing.Size(168, 22)
        Me.ChangePasswordToolStripMenuItem2.Text = "Change Password"
        '
        'HelpToolStripMenuItem2
        '
        Me.HelpToolStripMenuItem2.Name = "HelpToolStripMenuItem2"
        Me.HelpToolStripMenuItem2.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem2.Text = "Help"
        '
        'AboutToolStripMenuItem3
        '
        Me.AboutToolStripMenuItem3.Name = "AboutToolStripMenuItem3"
        Me.AboutToolStripMenuItem3.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem3.Text = "About"
        '
        'ReadMeToolStripMenuItem2
        '
        Me.ReadMeToolStripMenuItem2.Name = "ReadMeToolStripMenuItem2"
        Me.ReadMeToolStripMenuItem2.Size = New System.Drawing.Size(152, 22)
        Me.ReadMeToolStripMenuItem2.Text = "Read Me"
        '
        'MenuToolStripMenuItem1
        '
        Me.MenuToolStripMenuItem1.Name = "MenuToolStripMenuItem1"
        Me.MenuToolStripMenuItem1.Size = New System.Drawing.Size(50, 20)
        Me.MenuToolStripMenuItem1.Text = "Menu"
        '
        'ExitToolStripMenuItem5
        '
        Me.ExitToolStripMenuItem5.Name = "ExitToolStripMenuItem5"
        Me.ExitToolStripMenuItem5.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem5.Text = "Exit"
        '
        'SettingsToolStripMenuItem5
        '
        Me.SettingsToolStripMenuItem5.Name = "SettingsToolStripMenuItem5"
        Me.SettingsToolStripMenuItem5.Size = New System.Drawing.Size(61, 20)
        Me.SettingsToolStripMenuItem5.Text = "Settings"
        '
        'ChangePasswordToolStripMenuItem3
        '
        Me.ChangePasswordToolStripMenuItem3.Name = "ChangePasswordToolStripMenuItem3"
        Me.ChangePasswordToolStripMenuItem3.Size = New System.Drawing.Size(168, 22)
        Me.ChangePasswordToolStripMenuItem3.Text = "Change Password"
        '
        'HelpToolStripMenuItem3
        '
        Me.HelpToolStripMenuItem3.Name = "HelpToolStripMenuItem3"
        Me.HelpToolStripMenuItem3.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem3.Text = "Help"
        '
        'AboutToolStripMenuItem4
        '
        Me.AboutToolStripMenuItem4.Name = "AboutToolStripMenuItem4"
        Me.AboutToolStripMenuItem4.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem4.Text = "About "
        '
        'ReadMeToolStripMenuItem3
        '
        Me.ReadMeToolStripMenuItem3.Name = "ReadMeToolStripMenuItem3"
        Me.ReadMeToolStripMenuItem3.Size = New System.Drawing.Size(152, 22)
        Me.ReadMeToolStripMenuItem3.Text = "Read Me"
        '
        'MenuToolStripMenuItem2
        '
        Me.MenuToolStripMenuItem2.Name = "MenuToolStripMenuItem2"
        Me.MenuToolStripMenuItem2.Size = New System.Drawing.Size(50, 20)
        Me.MenuToolStripMenuItem2.Text = "Menu"
        '
        'ExitToolStripMenuItem6
        '
        Me.ExitToolStripMenuItem6.Name = "ExitToolStripMenuItem6"
        Me.ExitToolStripMenuItem6.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem6.Text = "Exit"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 188)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(224, 248)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem3, Me.SettingsToolStripMenuItem6, Me.HelpToolStripMenuItem4})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(891, 27)
        Me.MenuStrip1.TabIndex = 7
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuToolStripMenuItem3
        '
        Me.MenuToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem7})
        Me.MenuToolStripMenuItem3.Name = "MenuToolStripMenuItem3"
        Me.MenuToolStripMenuItem3.Size = New System.Drawing.Size(58, 23)
        Me.MenuToolStripMenuItem3.Text = "Menu"
        '
        'ExitToolStripMenuItem7
        '
        Me.ExitToolStripMenuItem7.Name = "ExitToolStripMenuItem7"
        Me.ExitToolStripMenuItem7.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.ExitToolStripMenuItem7.Size = New System.Drawing.Size(152, 24)
        Me.ExitToolStripMenuItem7.Text = "Exit"
        '
        'SettingsToolStripMenuItem6
        '
        Me.SettingsToolStripMenuItem6.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem4})
        Me.SettingsToolStripMenuItem6.Name = "SettingsToolStripMenuItem6"
        Me.SettingsToolStripMenuItem6.Size = New System.Drawing.Size(73, 23)
        Me.SettingsToolStripMenuItem6.Text = "Settings"
        '
        'ChangePasswordToolStripMenuItem4
        '
        Me.ChangePasswordToolStripMenuItem4.Name = "ChangePasswordToolStripMenuItem4"
        Me.ChangePasswordToolStripMenuItem4.Size = New System.Drawing.Size(193, 24)
        Me.ChangePasswordToolStripMenuItem4.Text = "Change Password"
        '
        'HelpToolStripMenuItem4
        '
        Me.HelpToolStripMenuItem4.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem5, Me.ReadMeToolStripMenuItem4})
        Me.HelpToolStripMenuItem4.Name = "HelpToolStripMenuItem4"
        Me.HelpToolStripMenuItem4.Size = New System.Drawing.Size(51, 23)
        Me.HelpToolStripMenuItem4.Text = "Help"
        '
        'AboutToolStripMenuItem5
        '
        Me.AboutToolStripMenuItem5.Name = "AboutToolStripMenuItem5"
        Me.AboutToolStripMenuItem5.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.AboutToolStripMenuItem5.Size = New System.Drawing.Size(160, 24)
        Me.AboutToolStripMenuItem5.Text = "About"
        '
        'ReadMeToolStripMenuItem4
        '
        Me.ReadMeToolStripMenuItem4.Name = "ReadMeToolStripMenuItem4"
        Me.ReadMeToolStripMenuItem4.ShortcutKeys = System.Windows.Forms.Keys.F2
        Me.ReadMeToolStripMenuItem4.Size = New System.Drawing.Size(160, 24)
        Me.ReadMeToolStripMenuItem4.Text = "Read Me"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(891, 550)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Copperplate Gothic Bold", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "My Diary"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MainToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents SettingsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutSoftwareToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReadMeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents MainToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChnagePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReadMeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MenuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReadMeToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReadMeToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReadMeToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem

End Class
