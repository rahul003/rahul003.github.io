Software: MY DIARY

Details:

This is a Diary software made by Rahul R Huilgol, as part of an project for the course Software Engineering. 
The software allows the user to set passwords, create entries, edit entries, delete them and view all the entries.

How To Use:
1. First, set a password on the first run.
2. The next time onwards, you will be asked to enter this password to login to the diary interface.
3. Click on create entry to open creation form. Here enter title, select date and express your thoughts. Click on Save to save the entry. We dont allow multiple entries on the same day. Instead, edit the earlier entry.
4. Double click on an entry in the list of entries to open it for editing. Edit whatever you want and click save to update it.
5. You can delete an entry by selecting it and clicking on delete button.
6. You change password by going to change password in Settings Menu Bar item.
7. To view this README file, go to Help - > Readme or press F2.
8. You can exit whenever you want.

All the entries are stored in encrypted format. you can rest assured about your privacy. :)